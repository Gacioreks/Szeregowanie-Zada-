#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <string>
#include <chrono>
#include <cmath>
#include <sstream>

struct Task {
    int id;        // Task ID
    int p;         // Processing time
    int r;         // Ready time
    int d;         // Due date
    double finish; // Finish time (used in scheduling)
};

struct Machine {
    double speed;  // Speed of the machine
    double available_time; // When the machine becomes available
    std::vector<int> assigned_tasks; // Tasks assigned to this machine
};

bool compare_ready_time(const Task& a, const Task& b) {
    return a.r < b.r;
}

void load_instance(const std::string& filename, std::vector<Machine>& machines, std::vector<Task>& tasks) {
    std::ifstream infile(filename);
    if (!infile.is_open()) {
        throw std::runtime_error("Could not open file.");
    }

    int n;
    infile >> n;

    machines.resize(5);
    for (int i = 0; i < 5; ++i) {
        infile >> machines[i].speed;
        machines[i].available_time = 0.0;
    }

    tasks.resize(n);
    for (int i = 0; i < n; ++i) {
        tasks[i].id = i + 1; // Use 1-based indexing
        infile >> tasks[i].p >> tasks[i].r >> tasks[i].d;
    }
    infile.close();
}

double schedule_tasks(std::vector<Machine>& machines, std::vector<Task>& tasks, double time_limit) {
    auto start_time = std::chrono::high_resolution_clock::now();

    // Sort tasks by ready time
    std::sort(tasks.begin(), tasks.end(), compare_ready_time);

    double total_lateness = 0.0;

    for (Task& task : tasks) {
        // Find the best machine for this task
        Machine* best_machine = nullptr;
        double best_finish_time = std::numeric_limits<double>::max();

        for (Machine& machine : machines) {
            double start_time = std::max(static_cast<double>(task.r), machine.available_time);
            double finish_time = start_time + (task.p * machine.speed);
            if (finish_time < best_finish_time) {
                best_finish_time = finish_time;
                best_machine = &machine;
            }
        }

        // Assign task to the best machine
        if (best_machine) {
            best_machine->available_time = best_finish_time;
            best_machine->assigned_tasks.push_back(task.id); // Store task ID
            task.finish = best_finish_time;

            // Calculate lateness for this task
            double lateness = std::max(task.finish - task.d, 0.0);
            total_lateness += std::min(lateness, static_cast<double>(task.p));
        }

        // Check if we've exceeded the time limit
        auto elapsed = std::chrono::high_resolution_clock::now() - start_time;
        if (std::chrono::duration<double>(elapsed).count() >= time_limit) {
            break; // Stop if time limit is exceeded
        }
    }

    return total_lateness;
}

void write_output(const std::string& input_filename, double total_lateness, const std::vector<Machine>& machines) {
    // Parse the input filename to extract ID and instance number
    std::string id, instance_n;
    size_t pos1 = input_filename.find("_");
    size_t pos2 = input_filename.rfind("_");
    if (pos1 != std::string::npos && pos2 != std::string::npos && pos1 != pos2) {
        id = input_filename.substr(pos1 + 1, pos2 - pos1 - 1);
        instance_n = input_filename.substr(pos2 + 1, input_filename.size() - pos2 - 5); // Exclude ".txt"
    } else {
        throw std::runtime_error("Invalid input filename format.");
    }

    // Generate output filename
    std::string output_filename = "out_" + id + "_145270_" + instance_n + ".txt";

    std::ofstream outfile(output_filename);
    if (!outfile.is_open()) {
        throw std::runtime_error("Could not open output file.");
    }

    // Write total lateness
    outfile << total_lateness << "\n";

    // Write tasks assigned to each machine
    for (const auto& machine : machines) {
        for (int task_id : machine.assigned_tasks) {
            outfile << task_id << " ";
        }
        outfile << "\n";
    }

    outfile.close();
    std::cout << "Output written to " << output_filename << "\n";
}

int main(int argc, char* argv[]) {
    if (argc != 2) {
        std::cerr << "Usage: " << argv[0] << " <input_file>" << std::endl;
        return 1;
    }

    std::string filename = argv[1];
    std::vector<Machine> machines;
    std::vector<Task> tasks;

    try {
        load_instance(filename, machines, tasks);
    } catch (const std::exception& e) {
        std::cerr << e.what() << std::endl;
        return 1;
    }

    int n = tasks.size();
    double time_limit = n / 10.0; // Time limit in seconds

    auto start_time = std::chrono::high_resolution_clock::now();
    double total_lateness = schedule_tasks(machines, tasks, time_limit);
    auto end_time = std::chrono::high_resolution_clock::now();

    double elapsed_time = std::chrono::duration<double>(end_time - start_time).count();

    // Print to console
    std::cout << "Total Lateness: " << total_lateness << "\n";
    std::cout << "Time Elapsed: " << elapsed_time << " seconds\n";

    try {
        write_output(filename, total_lateness, machines);
    } catch (const std::exception& e) {
        std::cerr << e.what() << std::endl;
        return 1;
    }

    return 0;
}
